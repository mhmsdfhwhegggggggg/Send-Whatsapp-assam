# Test Credentials

## Admin (Auto-seeded on first run)
- URL: /login
- Username: `admin`
- Password: `admin123`
- Role: admin

Notes:
- Created automatically by the FastAPI `seed()` startup event in `/app/backend/server.py`
- Settings document also auto-created with id="global"
