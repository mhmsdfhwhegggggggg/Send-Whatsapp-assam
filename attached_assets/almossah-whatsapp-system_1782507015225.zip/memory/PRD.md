# PRD — نظام إرسال رسائل WhatsApp الجماعي

## المؤسسة
المؤسسة الوطنية للتنمية الشاملة (يمن) — جهة غير ربحية تقدم خدمات تعليمية وصحية مجانية.

## المشكلة الأصلية
طلب نسخ وتطوير نظام إرسال رسائل واتساب جماعي للطلاب المسجلين (موافقة opt-in) الذين حصلوا على منح وخدمات. الميزانية = صفر (مؤسسة خيرية).

## القرار المعماري
- استبعاد طلب "تجاوز خوارزميات الحظر" (ينتهك ToS وقد يكون احتيالاً)
- المؤسسة شرعية ومستفيدوها مسجلون => Use case مشروع
- تبني نهج Baileys (WhatsApp Web Multi-Device) كحل مجاني مفتوح المصدر
- تطبيق ممارسات تقليل الحظر الشرعية (rate limit, account rotation, spintax, working hours)

## البنية التقنية
- **Frontend**: React + Tailwind + shadcn/ui — Arabic RTL — Alexandria + IBM Plex Sans Arabic
- **Backend**: FastAPI + MongoDB (motor) + JWT auth + bcrypt
- **WhatsApp Worker**: Node.js + @whiskeysockets/baileys + Express (port 8088) — يدير الجلسات
- **التواصل**: FastAPI ↔ Worker عبر HTTP

## ما تم تنفيذه (06 يونيو 2026)
- ✅ Auth (JWT) مع seed تلقائي لحساب admin/admin123
- ✅ CRUD: المستفيدون (مع استيراد CSV)، المجموعات، القوالب، الحسابات، الحملات، الإعدادات
- ✅ صفحة QR Code مع polling لربط حسابات WhatsApp جديدة
- ✅ Background sender مع:
  - Random delays (min/max)
  - Account rotation (round-robin)
  - Batch pauses بعد كل N رسالة
  - Working hours filtering
  - Spintax `{a|b}` parsing
  - Invisible zero-width chars injection
  - Variable replacement: `{اسم} {جامعة} {تخفيض} {خدمة}`
- ✅ Dashboard stats live (auto-refresh كل 5 ثوان)
- ✅ Campaign detail page مع real-time progress + رسائل
- ✅ Baileys worker مع typing simulation + session persistence على disk
- ✅ Supervisor config: `/etc/supervisor/conf.d/whatsapp_worker.conf`

## API Endpoints
- POST `/api/auth/login` → token
- GET/POST/PUT/DELETE `/api/students` + `/api/students/import`
- GET/POST/DELETE `/api/groups`
- GET/POST/PUT/DELETE `/api/templates`
- GET/POST/DELETE `/api/accounts` + GET `/api/accounts/{id}/qr`
- GET/POST `/api/campaigns` + `/api/campaigns/{id}/start|pause`
- GET/PUT `/api/settings`
- GET `/api/stats`

## P0 Backlog (Pending)
- اختبار end-to-end فعلي بربط حساب WhatsApp حقيقي ومسح QR
- إضافة Excel (.xlsx) support للاستيراد بجانب CSV
- إضافة Proxy support per account (SOCKS5) — البنية موجودة في الإعدادات

## P1
- نظام أدوار (Roles): admin / operator
- تقرير قابل للتصدير (CSV) لكل حملة
- جدولة الحملات (scheduled_at موجود في الـ model)

## P2
- استئناف تلقائي بعد إعادة التشغيل (المهام الخلفية حالياً in-memory)
- WebSocket للتحديث الفوري بدل polling
- نظام إشعارات داخل اللوحة
- دمج Redis + BullMQ للمقياس الكبير (مثل المستودع الأصلي)

## بيانات الدخول
admin / admin123 (ملف `/app/memory/test_credentials.md`)
