# نظام إرسال رسائل واتساب الجماعي
## المؤسسة الوطنية للتنمية الشاملة

نظام احترافي لإرسال رسائل واتساب جماعية للمستفيدين من خدمات المؤسسة التعليمية والصحية، مع تطبيق ممارسات تقليل الحظر.

## البنية التقنية

- **Frontend**: React + Tailwind + shadcn/ui (المنفذ 80)
- **Backend**: FastAPI + MongoDB (المنفذ 8001)
- **WhatsApp Worker**: Node.js + Baileys (المنفذ 8088)
- **Nginx**: Reverse proxy

## النشر السريع

### 1. الحصول على خادم مجاني

**الموصى به: Oracle Cloud Free Tier** (4 ARM CPU + 24GB RAM — مجاني للأبد)

بدائل: AWS Free Tier (12 شهر)، Google Cloud Free، Fly.io

### 2. النشر بأمر واحد

```bash
git clone https://github.com/YOUR_USERNAME/YOUR_REPO.git
cd YOUR_REPO
chmod +x deploy.sh
./deploy.sh
```

في التشغيل الأول سيُنشأ ملف `.env`. عدّل `REACT_APP_BACKEND_URL` ثم أعد التشغيل.

### 3. فتح المنافذ

```bash
sudo ufw allow 80,443,22/tcp && sudo ufw enable
```

### 4. (اختياري) شهادة SSL مجانية

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### 5. الدخول

`http://YOUR_SERVER_IP` — `admin / admin123`

**⚠️ غيّر كلمة المرور فوراً**

## التطوير المحلي

```bash
# Backend
cd backend && pip install -r requirements.txt && uvicorn server:app --reload --port 8001

# Worker  
cd whatsapp_worker && npm install && node server.js

# Frontend
cd frontend && yarn install && yarn start
```

## الأوامر المفيدة

```bash
sudo docker compose logs -f          # متابعة السجلات
sudo docker compose restart backend  # إعادة تشغيل خدمة
sudo docker compose down             # إيقاف الكل
git pull && sudo docker compose up -d --build  # تحديث
```

## التحذيرات

⚠️ يستخدم النظام بروتوكول WhatsApp Web غير الرسمي. لتقليل خطر الحظر:

1. ابدأ بأقل من 500 رسالة/يومياً لكل حساب جديد
2. استخدم 3+ حسابات
3. أرسل فقط للمسجلين (opt-in)
4. استخدم Spintax لتنويع النصوص
5. التزم بساعات العمل (9 ص - 9 م)

## الترخيص

MIT — للاستخدام الخيري للمؤسسة الوطنية للتنمية الشاملة
