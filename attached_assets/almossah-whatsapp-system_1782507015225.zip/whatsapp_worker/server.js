import express from 'express';
import cors from 'cors';
import pino from 'pino';
import qrcode from 'qrcode';
import { makeWASocket, useMultiFileAuthState, DisconnectReason, Browsers } from '@whiskeysockets/baileys';
import fs from 'fs';
import path from 'path';

const PORT = process.env.WORKER_PORT || 8088;
const SESSIONS_DIR = path.resolve('./sessions');
if (!fs.existsSync(SESSIONS_DIR)) fs.mkdirSync(SESSIONS_DIR, { recursive: true });

const logger = pino({ level: 'warn' });
const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// In-memory session registry
const sessions = new Map(); // id -> { sock, status, qr, phoneNumber, label }

async function startSession(id, label) {
  const dir = path.join(SESSIONS_DIR, id);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  const { state, saveCreds } = await useMultiFileAuthState(dir);

  const sock = makeWASocket({
    auth: state,
    logger,
    printQRInTerminal: false,
    browser: Browsers.macOS('Desktop'),
    syncFullHistory: false,
    markOnlineOnConnect: false,
  });

  const entry = sessions.get(id) || { label, status: 'initializing', qr: null, phoneNumber: null };
  entry.sock = sock;
  entry.label = label || entry.label;
  sessions.set(id, entry);

  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect, qr } = update;
    const e = sessions.get(id);
    if (!e) return;
    if (qr) {
      e.qr = await qrcode.toDataURL(qr);
      e.status = 'qr';
    }
    if (connection === 'open') {
      e.status = 'connected';
      e.qr = null;
      e.phoneNumber = sock.user?.id?.split(':')[0] || sock.user?.id || null;
      console.log(`[${id}] connected as ${e.phoneNumber}`);
    } else if (connection === 'close') {
      const code = lastDisconnect?.error?.output?.statusCode;
      const loggedOut = code === DisconnectReason.loggedOut;
      e.status = loggedOut ? 'logged_out' : 'disconnected';
      e.qr = null;
      console.log(`[${id}] disconnected, code=${code}, loggedOut=${loggedOut}`);
      if (!loggedOut) {
        setTimeout(() => startSession(id, e.label).catch(err => console.error(err)), 3000);
      }
    }
  });
}

// Restore existing sessions on boot
async function restoreAll() {
  if (!fs.existsSync(SESSIONS_DIR)) return;
  const ids = fs.readdirSync(SESSIONS_DIR).filter(f => fs.statSync(path.join(SESSIONS_DIR, f)).isDirectory());
  for (const id of ids) {
    try { await startSession(id, id); } catch (e) { console.error('restore failed', id, e.message); }
  }
}

app.get('/health', (req, res) => res.json({ ok: true, sessions: sessions.size }));

app.get('/sessions', (req, res) => {
  const list = [];
  for (const [id, e] of sessions.entries()) {
    list.push({ id, label: e.label, status: e.status, phoneNumber: e.phoneNumber });
  }
  res.json(list);
});

app.post('/sessions', async (req, res) => {
  const { id, label } = req.body;
  if (!id) return res.status(400).json({ error: 'id required' });
  if (sessions.has(id) && sessions.get(id).status === 'connected') {
    return res.json({ ok: true, status: 'connected' });
  }
  try {
    await startSession(id, label);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/sessions/:id/qr', (req, res) => {
  const e = sessions.get(req.params.id);
  if (!e) return res.json({ qr: null, status: 'not_started' });
  res.json({ qr: e.qr, status: e.status });
});

app.delete('/sessions/:id', async (req, res) => {
  const id = req.params.id;
  const e = sessions.get(id);
  if (e?.sock) {
    try { await e.sock.logout(); } catch {}
    try { e.sock.end(); } catch {}
  }
  sessions.delete(id);
  const dir = path.join(SESSIONS_DIR, id);
  if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
  res.json({ ok: true });
});

app.post('/send', async (req, res) => {
  const { sessionId, phone, text } = req.body;
  if (!sessionId || !phone || !text) return res.status(400).json({ error: 'missing fields' });
  const e = sessions.get(sessionId);
  if (!e || e.status !== 'connected') return res.status(400).json({ error: 'session_not_connected', status: e?.status });
  try {
    // Normalize phone
    let p = String(phone).replace(/\D/g, '');
    const jid = p + '@s.whatsapp.net';
    // Optional: simulate typing for human-like behavior
    try {
      await e.sock.sendPresenceUpdate('composing', jid);
      await new Promise(r => setTimeout(r, Math.min(3000, text.length * 50)));
      await e.sock.sendPresenceUpdate('paused', jid);
    } catch {}
    const msg = await e.sock.sendMessage(jid, { text });
    res.json({ ok: true, id: msg?.key?.id });
  } catch (err) {
    console.error('send error', err);
    res.status(500).json({ error: err.message });
  }
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[worker] listening on ${PORT}`);
  restoreAll().catch(console.error);
});
