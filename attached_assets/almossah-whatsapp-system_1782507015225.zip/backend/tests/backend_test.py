"""Backend API tests for AlMossah WhatsApp System."""
import os, io, time, pytest, requests

BASE = os.environ.get("REACT_APP_BACKEND_URL", "https://47354524-6c7c-4521-a5db-5d928f9a9b1e.preview.emergentagent.com").rstrip("/")
API = f"{BASE}/api"


@pytest.fixture(scope="session")
def token():
    r = requests.post(f"{API}/auth/login", json={"username": "admin", "password": "admin123"}, timeout=15)
    assert r.status_code == 200, r.text
    data = r.json()
    assert "token" in data and data["user"]["username"] == "admin"
    return data["token"]


@pytest.fixture(scope="session")
def h(token):
    return {"Authorization": f"Bearer {token}"}


# ===== Auth =====
def test_login_bad_creds():
    r = requests.post(f"{API}/auth/login", json={"username": "admin", "password": "wrong"}, timeout=10)
    assert r.status_code == 401

def test_me_no_token():
    r = requests.get(f"{API}/auth/me", timeout=10)
    assert r.status_code == 401

def test_me_bad_token():
    r = requests.get(f"{API}/auth/me", headers={"Authorization": "Bearer foo"}, timeout=10)
    assert r.status_code == 401

def test_me_ok(h):
    r = requests.get(f"{API}/auth/me", headers=h, timeout=10)
    assert r.status_code == 200
    assert r.json()["username"] == "admin"


# ===== Unauthorized checks for protected endpoints =====
@pytest.mark.parametrize("method,path", [
    ("GET", "/students"), ("POST", "/students"), ("GET", "/groups"),
    ("GET", "/templates"), ("GET", "/accounts"), ("GET", "/campaigns"),
    ("GET", "/settings"), ("GET", "/stats"),
])
def test_protected_requires_auth(method, path):
    r = requests.request(method, f"{API}{path}", json={} if method == "POST" else None, timeout=10)
    assert r.status_code == 401


# ===== Groups CRUD =====
def test_groups_crud(h):
    r = requests.post(f"{API}/groups", json={"name": "TEST_grp", "description": "d"}, headers=h, timeout=10)
    assert r.status_code == 200
    gid = r.json()["id"]
    r = requests.get(f"{API}/groups", headers=h, timeout=10)
    assert r.status_code == 200 and any(g["id"] == gid for g in r.json())
    pytest.gid = gid


# ===== Students CRUD + Import + Filter =====
def test_students_crud_filter_import(h):
    gid = pytest.gid
    # create
    payload = {"name": "TEST_Ahmad", "phone": "+967-771-234-567", "university": "Sanaa U",
               "service_type": "scholarship", "discount": "50%", "group_id": gid}
    r = requests.post(f"{API}/students", json=payload, headers=h, timeout=10)
    assert r.status_code == 200
    sid = r.json()["id"]
    assert r.json()["phone"] == "967771234567"  # sanitization

    # filter by group
    r = requests.get(f"{API}/students", params={"group_id": gid}, headers=h, timeout=10)
    assert r.status_code == 200 and any(s["id"] == sid for s in r.json())

    # search
    r = requests.get(f"{API}/students", params={"q": "TEST_Ahmad"}, headers=h, timeout=10)
    assert r.status_code == 200 and len(r.json()) >= 1

    # update
    payload["name"] = "TEST_Ahmad2"
    r = requests.put(f"{API}/students/{sid}", json=payload, headers=h, timeout=10)
    assert r.status_code == 200
    r = requests.get(f"{API}/students", params={"q": "TEST_Ahmad2"}, headers=h, timeout=10)
    assert any(s["id"] == sid for s in r.json())

    # CSV import
    csv_data = "name,phone,university,service_type,discount\nTEST_csv1,967700111222,U1,sch,30%\nTEST_csv2,967700333444,U2,disc,40%\n"
    files = {"file": ("s.csv", io.BytesIO(csv_data.encode()), "text/csv")}
    r = requests.post(f"{API}/students/import", files=files, params={"group_id": gid}, headers=h, timeout=15)
    assert r.status_code == 200 and r.json()["imported"] == 2

    pytest.sid = sid


# ===== Templates CRUD =====
def test_templates_crud(h):
    r = requests.post(f"{API}/templates", json={"name": "TEST_tpl", "body": "مرحبا {name} - {اسم}", "description": "d"}, headers=h, timeout=10)
    assert r.status_code == 200
    tid = r.json()["id"]
    r = requests.put(f"{API}/templates/{tid}", json={"name": "TEST_tpl2", "body": "B", "description": ""}, headers=h, timeout=10)
    assert r.status_code == 200
    r = requests.get(f"{API}/templates", headers=h, timeout=10)
    assert any(t["id"] == tid and t["name"] == "TEST_tpl2" for t in r.json())
    pytest.tid = tid


# ===== Settings =====
def test_settings(h):
    r = requests.get(f"{API}/settings", headers=h, timeout=10)
    assert r.status_code == 200 and r.json()["id"] == "global"
    r = requests.put(f"{API}/settings", json={"daily_limit_per_account": 600, "working_hours_start": 8,
                                              "working_hours_end": 22, "spintax_enabled": True,
                                              "invisible_chars_enabled": False}, headers=h, timeout=10)
    assert r.status_code == 200
    r = requests.get(f"{API}/settings", headers=h, timeout=10)
    assert r.json()["daily_limit_per_account"] == 600 and r.json()["invisible_chars_enabled"] is False


# ===== Accounts =====
def test_accounts(h):
    r = requests.post(f"{API}/accounts", json={"label": "TEST_acc"}, headers=h, timeout=15)
    assert r.status_code == 200
    aid = r.json()["id"]
    assert r.json()["status"] in ("initializing", "qr", "connecting", "connected", "disconnected")
    r = requests.get(f"{API}/accounts", headers=h, timeout=15)
    assert r.status_code == 200 and any(a["id"] == aid for a in r.json())
    r = requests.get(f"{API}/accounts/{aid}/qr", headers=h, timeout=10)
    assert r.status_code == 200 and "qr" in r.json()
    pytest.aid = aid


# ===== Stats =====
def test_stats(h):
    r = requests.get(f"{API}/stats", headers=h, timeout=10)
    assert r.status_code == 200
    d = r.json()
    for k in ["students", "groups", "templates", "accounts", "campaigns",
              "messages_sent", "messages_failed", "messages_pending"]:
        assert k in d and isinstance(d[k], int)


# ===== Campaigns =====
def test_campaign_validations(h):
    r = requests.post(f"{API}/campaigns", json={"name": "TEST_c", "template_id": pytest.tid,
                                                "account_ids": [pytest.aid]}, headers=h, timeout=10)
    assert r.status_code == 400  # no recipients

    r = requests.post(f"{API}/campaigns", json={"name": "TEST_c", "template_id": pytest.tid,
                                                "group_ids": [pytest.gid], "account_ids": []}, headers=h, timeout=10)
    assert r.status_code == 400  # no accounts

    r = requests.post(f"{API}/campaigns", json={"name": "TEST_c", "template_id": "nonexistent",
                                                "group_ids": [pytest.gid], "account_ids": [pytest.aid]}, headers=h, timeout=10)
    assert r.status_code == 400  # bad template


def test_campaign_create_and_run(h):
    r = requests.post(f"{API}/campaigns", json={
        "name": "TEST_camp1", "template_id": pytest.tid,
        "group_ids": [pytest.gid], "account_ids": [pytest.aid],
        "min_delay_sec": 1, "max_delay_sec": 2, "batch_size": 100, "batch_pause_min": 1,
    }, headers=h, timeout=15)
    assert r.status_code == 200
    cid = r.json()["id"]
    assert r.json()["status"] == "running"
    assert r.json()["recipients_count"] >= 1

    # list
    r = requests.get(f"{API}/campaigns", headers=h, timeout=10)
    found = [c for c in r.json() if c["id"] == cid]
    assert found
    c = found[0]
    for k in ["total", "sent", "failed", "pending"]:
        assert k in c

    # detail
    r = requests.get(f"{API}/campaigns/{cid}", headers=h, timeout=10)
    assert r.status_code == 200
    detail = r.json()
    assert "messages" in detail and detail["total"] >= 1

    # pause
    r = requests.post(f"{API}/campaigns/{cid}/pause", headers=h, timeout=10)
    assert r.status_code == 200
    r = requests.get(f"{API}/campaigns/{cid}", headers=h, timeout=10)
    # status may be paused (sender loop checks)
    # start again
    r = requests.post(f"{API}/campaigns/{cid}/start", headers=h, timeout=10)
    assert r.status_code == 200

    # Wait for background sender to process: messages should transition pending -> failed
    deadline = time.time() + 30
    while time.time() < deadline:
        r = requests.get(f"{API}/campaigns/{cid}", headers=h, timeout=10)
        d = r.json()
        if d["failed"] + d["sent"] >= 1:
            break
        time.sleep(2)
    r = requests.get(f"{API}/campaigns/{cid}", headers=h, timeout=10)
    d = r.json()
    # At least one message should have moved out of pending (worker likely returns session_not_connected -> failed)
    assert (d["failed"] + d["sent"]) >= 1, f"No messages processed: {d}"
    # Verify error stored
    failed_msgs = [m for m in d["messages"] if m["status"] == "failed"]
    if failed_msgs:
        assert failed_msgs[0]["error"] is not None
    pytest.cid = cid


# ===== Cleanup =====
def test_zz_cleanup(h):
    # delete campaign
    if hasattr(pytest, "cid"):
        requests.delete(f"{API}/campaigns/{pytest.cid}", headers=h, timeout=10)
    # delete template
    if hasattr(pytest, "tid"):
        requests.delete(f"{API}/templates/{pytest.tid}", headers=h, timeout=10)
    # delete account
    if hasattr(pytest, "aid"):
        requests.delete(f"{API}/accounts/{pytest.aid}", headers=h, timeout=10)
    # delete group -> should unlink students
    gid = pytest.gid
    requests.delete(f"{API}/groups/{gid}", headers=h, timeout=10)
    # verify unlink
    r = requests.get(f"{API}/students", params={"group_id": gid}, headers=h, timeout=10)
    assert r.json() == [] or all(s.get("group_id") != gid for s in r.json())
    # delete test students
    r = requests.get(f"{API}/students", params={"q": "TEST_"}, headers=h, timeout=10)
    for s in r.json():
        if s.get("name", "").startswith("TEST_"):
            requests.delete(f"{API}/students/{s['id']}", headers=h, timeout=10)
