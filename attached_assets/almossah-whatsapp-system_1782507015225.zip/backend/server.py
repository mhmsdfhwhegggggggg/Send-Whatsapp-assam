from fastapi import FastAPI, APIRouter, HTTPException, Depends, UploadFile, File, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os, logging, asyncio, random, io, csv, jwt, bcrypt, httpx, json
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Dict, Any
from datetime import datetime, timezone, timedelta
import uuid

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

JWT_SECRET = os.environ.get('JWT_SECRET', 'almossah-secret-change-me-in-prod')
JWT_ALG = 'HS256'
WORKER_URL = os.environ.get('WORKER_URL', 'http://localhost:8088')

app = FastAPI(title="AlMossah WhatsApp System")
api = APIRouter(prefix="/api")
security = HTTPBearer(auto_error=False)
logger = logging.getLogger("almossah")
logging.basicConfig(level=logging.INFO)


def now_iso(): return datetime.now(timezone.utc).isoformat()
def new_id(): return str(uuid.uuid4())


# ===== Models =====
class UserCreate(BaseModel):
    username: str
    password: str
    role: str = "admin"

class LoginIn(BaseModel):
    username: str
    password: str

class StudentIn(BaseModel):
    name: str
    phone: str
    university: Optional[str] = None
    service_type: Optional[str] = None
    discount: Optional[str] = None
    group_id: Optional[str] = None
    extra: Optional[Dict[str, Any]] = {}

class GroupIn(BaseModel):
    name: str
    description: Optional[str] = ""

class TemplateIn(BaseModel):
    name: str
    body: str
    description: Optional[str] = ""

class AccountIn(BaseModel):
    label: str

class CampaignIn(BaseModel):
    name: str
    template_id: str
    group_ids: List[str] = []
    student_ids: List[str] = []
    account_ids: List[str] = []
    min_delay_sec: int = 5
    max_delay_sec: int = 25
    batch_size: int = 50
    batch_pause_min: int = 5
    scheduled_at: Optional[str] = None

class SettingsIn(BaseModel):
    daily_limit_per_account: int = 500
    working_hours_start: int = 9
    working_hours_end: int = 21
    spintax_enabled: bool = True
    invisible_chars_enabled: bool = True


# ===== Auth =====
def hash_pw(pw: str) -> str:
    return bcrypt.hashpw(pw.encode(), bcrypt.gensalt()).decode()

def verify_pw(pw: str, hashed: str) -> bool:
    try: return bcrypt.checkpw(pw.encode(), hashed.encode())
    except: return False

def make_token(user_id: str, role: str) -> str:
    payload = {"sub": user_id, "role": role, "exp": datetime.now(timezone.utc) + timedelta(days=7)}
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALG)

async def current_user(creds: HTTPAuthorizationCredentials = Depends(security)):
    if not creds:
        raise HTTPException(401, "Missing token")
    try:
        payload = jwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALG])
        user = await db.users.find_one({"id": payload["sub"]}, {"_id": 0, "password": 0})
        if not user: raise HTTPException(401, "Invalid token")
        return user
    except jwt.InvalidTokenError:
        raise HTTPException(401, "Invalid token")


# ===== Startup: seed admin =====
@app.on_event("startup")
async def seed():
    if await db.users.count_documents({}) == 0:
        await db.users.insert_one({
            "id": new_id(),
            "username": "admin",
            "password": hash_pw("admin123"),
            "role": "admin",
            "created_at": now_iso(),
        })
        logger.info("Seeded admin user: admin / admin123")
    if await db.settings.count_documents({}) == 0:
        await db.settings.insert_one({
            "id": "global",
            "daily_limit_per_account": 500,
            "working_hours_start": 9,
            "working_hours_end": 21,
            "spintax_enabled": True,
            "invisible_chars_enabled": True,
        })


# ===== Auth Routes =====
@api.post("/auth/login")
async def login(data: LoginIn):
    user = await db.users.find_one({"username": data.username})
    if not user or not verify_pw(data.password, user["password"]):
        raise HTTPException(401, "بيانات الدخول غير صحيحة")
    token = make_token(user["id"], user["role"])
    return {"token": token, "user": {"id": user["id"], "username": user["username"], "role": user["role"]}}

@api.get("/auth/me")
async def me(user = Depends(current_user)):
    return user


# ===== Students =====
@api.get("/students")
async def list_students(group_id: Optional[str] = None, q: Optional[str] = None, user=Depends(current_user)):
    flt = {}
    if group_id: flt["group_id"] = group_id
    if q: flt["$or"] = [{"name": {"$regex": q, "$options": "i"}}, {"phone": {"$regex": q}}]
    docs = await db.students.find(flt, {"_id": 0}).sort("created_at", -1).to_list(5000)
    return docs

@api.post("/students")
async def create_student(data: StudentIn, user=Depends(current_user)):
    doc = data.model_dump()
    doc["id"] = new_id()
    doc["created_at"] = now_iso()
    doc["phone"] = doc["phone"].replace("+", "").replace(" ", "").replace("-", "")
    await db.students.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.put("/students/{sid}")
async def update_student(sid: str, data: StudentIn, user=Depends(current_user)):
    update = data.model_dump()
    update["phone"] = update["phone"].replace("+", "").replace(" ", "").replace("-", "")
    await db.students.update_one({"id": sid}, {"$set": update})
    return {"ok": True}

@api.delete("/students/{sid}")
async def delete_student(sid: str, user=Depends(current_user)):
    await db.students.delete_one({"id": sid})
    return {"ok": True}

@api.post("/students/import")
async def import_students(file: UploadFile = File(...), group_id: Optional[str] = None, user=Depends(current_user)):
    content = await file.read()
    text = content.decode("utf-8-sig", errors="ignore")
    reader = csv.DictReader(io.StringIO(text))
    count = 0
    for row in reader:
        name = (row.get("name") or row.get("الاسم") or "").strip()
        phone = (row.get("phone") or row.get("الهاتف") or row.get("رقم") or "").strip()
        if not name or not phone: continue
        phone = phone.replace("+", "").replace(" ", "").replace("-", "")
        doc = {
            "id": new_id(),
            "name": name,
            "phone": phone,
            "university": (row.get("university") or row.get("الجامعة") or "").strip(),
            "service_type": (row.get("service_type") or row.get("الخدمة") or "").strip(),
            "discount": (row.get("discount") or row.get("التخفيض") or "").strip(),
            "group_id": group_id,
            "extra": {},
            "created_at": now_iso(),
        }
        await db.students.insert_one(doc)
        count += 1
    return {"imported": count}


# ===== Groups =====
@api.get("/groups")
async def list_groups(user=Depends(current_user)):
    docs = await db.groups.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)
    for g in docs:
        g["count"] = await db.students.count_documents({"group_id": g["id"]})
    return docs

@api.post("/groups")
async def create_group(data: GroupIn, user=Depends(current_user)):
    doc = {"id": new_id(), **data.model_dump(), "created_at": now_iso()}
    await db.groups.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.delete("/groups/{gid}")
async def delete_group(gid: str, user=Depends(current_user)):
    await db.groups.delete_one({"id": gid})
    await db.students.update_many({"group_id": gid}, {"$set": {"group_id": None}})
    return {"ok": True}


# ===== Templates =====
@api.get("/templates")
async def list_templates(user=Depends(current_user)):
    return await db.templates.find({}, {"_id": 0}).sort("created_at", -1).to_list(1000)

@api.post("/templates")
async def create_template(data: TemplateIn, user=Depends(current_user)):
    doc = {"id": new_id(), **data.model_dump(), "created_at": now_iso()}
    await db.templates.insert_one(doc)
    doc.pop("_id", None)
    return doc

@api.put("/templates/{tid}")
async def update_template(tid: str, data: TemplateIn, user=Depends(current_user)):
    await db.templates.update_one({"id": tid}, {"$set": data.model_dump()})
    return {"ok": True}

@api.delete("/templates/{tid}")
async def delete_template(tid: str, user=Depends(current_user)):
    await db.templates.delete_one({"id": tid})
    return {"ok": True}


# ===== WhatsApp Accounts =====
@api.get("/accounts")
async def list_accounts(user=Depends(current_user)):
    docs = await db.accounts.find({}, {"_id": 0}).sort("created_at", -1).to_list(100)
    # Refresh live status from worker
    async with httpx.AsyncClient(timeout=5) as cx:
        try:
            r = await cx.get(f"{WORKER_URL}/sessions")
            if r.status_code == 200:
                live = {s["id"]: s for s in r.json()}
                for a in docs:
                    if a["id"] in live:
                        a["status"] = live[a["id"]]["status"]
                        a["phone_number"] = live[a["id"]].get("phoneNumber") or a.get("phone_number")
        except Exception as e:
            logger.warning(f"Worker unreachable: {e}")
    return docs

@api.post("/accounts")
async def create_account(data: AccountIn, user=Depends(current_user)):
    aid = new_id()
    doc = {"id": aid, "label": data.label, "status": "initializing", "phone_number": None, "created_at": now_iso(), "sent_today": 0}
    await db.accounts.insert_one(doc)
    # Tell worker to start a session
    try:
        async with httpx.AsyncClient(timeout=10) as cx:
            await cx.post(f"{WORKER_URL}/sessions", json={"id": aid, "label": data.label})
    except Exception as e:
        logger.warning(f"Worker start failed: {e}")
    doc.pop("_id", None)
    return doc

@api.get("/accounts/{aid}/qr")
async def get_qr(aid: str, user=Depends(current_user)):
    try:
        async with httpx.AsyncClient(timeout=5) as cx:
            r = await cx.get(f"{WORKER_URL}/sessions/{aid}/qr")
            if r.status_code == 200:
                return r.json()
    except Exception as e:
        logger.warning(f"QR fetch failed: {e}")
    return {"qr": None, "status": "unknown"}

@api.delete("/accounts/{aid}")
async def delete_account(aid: str, user=Depends(current_user)):
    try:
        async with httpx.AsyncClient(timeout=5) as cx:
            await cx.delete(f"{WORKER_URL}/sessions/{aid}")
    except: pass
    await db.accounts.delete_one({"id": aid})
    return {"ok": True}


# ===== Helpers =====
def apply_spintax(text: str) -> str:
    import re
    def pick(m):
        opts = m.group(1).split("|")
        return random.choice(opts)
    while "{" in text and "|" in text and "}" in text:
        new = re.sub(r"\{([^{}]+\|[^{}]+)\}", pick, text)
        if new == text: break
        text = new
    return text

def fill_vars(text: str, student: dict) -> str:
    repl = {
        "{اسم}": student.get("name", ""),
        "{name}": student.get("name", ""),
        "{جامعة}": student.get("university", ""),
        "{university}": student.get("university", ""),
        "{تخفيض}": student.get("discount", ""),
        "{discount}": student.get("discount", ""),
        "{خدمة}": student.get("service_type", ""),
    }
    for k, v in repl.items():
        text = text.replace(k, str(v) if v else "")
    return text

def add_invisible(text: str) -> str:
    # Add zero-width chars to vary content slightly
    invisible = ["\u200B", "\u200C", "\u200D"]
    pos = random.randint(1, max(1, len(text) - 1))
    return text[:pos] + random.choice(invisible) + text[pos:]


# ===== Campaigns =====
@api.get("/campaigns")
async def list_campaigns(user=Depends(current_user)):
    docs = await db.campaigns.find({}, {"_id": 0}).sort("created_at", -1).to_list(200)
    for c in docs:
        c["total"] = await db.messages.count_documents({"campaign_id": c["id"]})
        c["sent"] = await db.messages.count_documents({"campaign_id": c["id"], "status": "sent"})
        c["failed"] = await db.messages.count_documents({"campaign_id": c["id"], "status": "failed"})
        c["pending"] = await db.messages.count_documents({"campaign_id": c["id"], "status": "pending"})
    return docs

@api.post("/campaigns")
async def create_campaign(data: CampaignIn, bg: BackgroundTasks, user=Depends(current_user)):
    cid = new_id()
    students = []
    if data.group_ids:
        s = await db.students.find({"group_id": {"$in": data.group_ids}}, {"_id": 0}).to_list(50000)
        students.extend(s)
    if data.student_ids:
        s = await db.students.find({"id": {"$in": data.student_ids}}, {"_id": 0}).to_list(50000)
        students.extend(s)
    seen = set(); unique = []
    for st in students:
        if st["id"] in seen: continue
        seen.add(st["id"]); unique.append(st)
    if not unique:
        raise HTTPException(400, "لا يوجد مستلمون")
    if not data.account_ids:
        raise HTTPException(400, "اختر حساب واتساب واحد على الأقل")
    template = await db.templates.find_one({"id": data.template_id})
    if not template:
        raise HTTPException(400, "القالب غير موجود")

    camp = {
        "id": cid, **data.model_dump(),
        "status": "pending" if data.scheduled_at else "running",
        "recipients_count": len(unique),
        "created_at": now_iso(),
        "started_at": None, "finished_at": None,
    }
    await db.campaigns.insert_one(camp)

    # Pre-create message records
    bulk = []
    for st in unique:
        bulk.append({
            "id": new_id(), "campaign_id": cid, "student_id": st["id"],
            "phone": st["phone"], "name": st["name"],
            "status": "pending", "error": None,
            "account_id": None, "sent_at": None, "created_at": now_iso(),
        })
    if bulk: await db.messages.insert_many(bulk)

    if not data.scheduled_at:
        bg.add_task(run_campaign, cid)
    camp.pop("_id", None)
    return camp

@api.get("/campaigns/{cid}")
async def campaign_detail(cid: str, user=Depends(current_user)):
    camp = await db.campaigns.find_one({"id": cid}, {"_id": 0})
    if not camp: raise HTTPException(404)
    msgs = await db.messages.find({"campaign_id": cid}, {"_id": 0}).sort("created_at", 1).limit(500).to_list(500)
    camp["messages"] = msgs
    camp["sent"] = await db.messages.count_documents({"campaign_id": cid, "status": "sent"})
    camp["failed"] = await db.messages.count_documents({"campaign_id": cid, "status": "failed"})
    camp["pending"] = await db.messages.count_documents({"campaign_id": cid, "status": "pending"})
    camp["total"] = await db.messages.count_documents({"campaign_id": cid})
    return camp

@api.post("/campaigns/{cid}/start")
async def start_campaign(cid: str, bg: BackgroundTasks, user=Depends(current_user)):
    await db.campaigns.update_one({"id": cid}, {"$set": {"status": "running", "started_at": now_iso()}})
    bg.add_task(run_campaign, cid)
    return {"ok": True}

@api.post("/campaigns/{cid}/pause")
async def pause_campaign(cid: str, user=Depends(current_user)):
    await db.campaigns.update_one({"id": cid}, {"$set": {"status": "paused"}})
    return {"ok": True}

@api.delete("/campaigns/{cid}")
async def delete_campaign(cid: str, user=Depends(current_user)):
    await db.campaigns.delete_one({"id": cid})
    await db.messages.delete_many({"campaign_id": cid})
    return {"ok": True}


async def run_campaign(cid: str):
    """Background sender with anti-ban: random delays, account rotation, batch pauses."""
    camp = await db.campaigns.find_one({"id": cid})
    if not camp: return
    template = await db.templates.find_one({"id": camp["template_id"]})
    if not template: return
    settings = await db.settings.find_one({"id": "global"}) or {}

    account_ids = camp.get("account_ids", [])
    if not account_ids: return

    sent_in_batch = 0
    idx = 0

    while True:
        camp = await db.campaigns.find_one({"id": cid})
        if not camp or camp.get("status") in ("paused", "stopped"): return

        msg = await db.messages.find_one({"campaign_id": cid, "status": "pending"}, sort=[("created_at", 1)])
        if not msg:
            await db.campaigns.update_one({"id": cid}, {"$set": {"status": "completed", "finished_at": now_iso()}})
            return

        # Working hours check
        now_h = datetime.now(timezone.utc).hour
        if not (settings.get("working_hours_start", 0) <= now_h < settings.get("working_hours_end", 24)):
            await asyncio.sleep(60); continue

        # Pick account (round-robin)
        account_id = account_ids[idx % len(account_ids)]
        idx += 1

        student = await db.students.find_one({"id": msg["student_id"]}, {"_id": 0}) or {"name": msg["name"], "phone": msg["phone"]}
        body = template["body"]
        if settings.get("spintax_enabled", True):
            body = apply_spintax(body)
        body = fill_vars(body, student)
        if settings.get("invisible_chars_enabled", True):
            body = add_invisible(body)

        # Send via worker
        sent_ok = False; err = None
        try:
            async with httpx.AsyncClient(timeout=30) as cx:
                r = await cx.post(f"{WORKER_URL}/send", json={
                    "sessionId": account_id, "phone": msg["phone"], "text": body
                })
                if r.status_code == 200 and r.json().get("ok"):
                    sent_ok = True
                else:
                    err = r.json().get("error", "send_failed")
        except Exception as e:
            err = str(e)

        await db.messages.update_one({"id": msg["id"]}, {"$set": {
            "status": "sent" if sent_ok else "failed",
            "error": err, "account_id": account_id, "sent_at": now_iso(),
        }})
        if sent_ok:
            await db.accounts.update_one({"id": account_id}, {"$inc": {"sent_today": 1}})
            sent_in_batch += 1

        # Random human-like delay
        delay = random.randint(camp.get("min_delay_sec", 5), camp.get("max_delay_sec", 25))
        await asyncio.sleep(delay)

        # Batch pause
        if sent_in_batch >= camp.get("batch_size", 50):
            pause_min = camp.get("batch_pause_min", 5)
            logger.info(f"Campaign {cid}: batch pause {pause_min} min")
            await asyncio.sleep(pause_min * 60)
            sent_in_batch = 0


# ===== Settings =====
@api.get("/settings")
async def get_settings(user=Depends(current_user)):
    s = await db.settings.find_one({"id": "global"}, {"_id": 0})
    return s

@api.put("/settings")
async def update_settings(data: SettingsIn, user=Depends(current_user)):
    await db.settings.update_one({"id": "global"}, {"$set": data.model_dump()})
    return {"ok": True}


# ===== Dashboard =====
@api.get("/stats")
async def stats(user=Depends(current_user)):
    return {
        "students": await db.students.count_documents({}),
        "groups": await db.groups.count_documents({}),
        "templates": await db.templates.count_documents({}),
        "accounts": await db.accounts.count_documents({}),
        "campaigns": await db.campaigns.count_documents({}),
        "messages_sent": await db.messages.count_documents({"status": "sent"}),
        "messages_failed": await db.messages.count_documents({"status": "failed"}),
        "messages_pending": await db.messages.count_documents({"status": "pending"}),
        "campaigns_running": await db.campaigns.count_documents({"status": "running"}),
        "campaigns_completed": await db.campaigns.count_documents({"status": "completed"}),
    }


@api.get("/")
async def root():
    return {"name": "AlMossah WhatsApp System", "version": "1.0"}


app.include_router(api)
app.add_middleware(
    CORSMiddleware, allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"], allow_headers=["*"],
)

@app.on_event("shutdown")
async def shutdown():
    client.close()
