#!/usr/bin/env bash
# سكريبت نشر تلقائي - Ubuntu 22.04 / Debian 12
set -e

echo "==> 1. تحديث النظام وتثبيت Docker"
sudo apt-get update -y
sudo apt-get install -y curl ca-certificates gnupg openssl
if ! command -v docker &> /dev/null; then
  curl -fsSL https://get.docker.com | sudo sh
  sudo usermod -aG docker $USER || true
fi

echo "==> 2. إعداد ملف .env"
if [ ! -f .env ]; then
  cp .env.example .env
  JWT=$(openssl rand -base64 64 | tr -d '\n' | head -c 64)
  # استبدال المفتاح
  sed -i "s|GENERATE_STRONG_SECRET_HERE_50_CHARS_MIN|${JWT}|" .env
  echo "   تم إنشاء .env. عدّل REACT_APP_BACKEND_URL لعنوان نطاقك."
  echo "   ثم أعد تشغيل هذا السكريبت."
  exit 0
fi

echo "==> 3. بناء الصور وتشغيل الخدمات"
sudo docker compose down 2>/dev/null || true
sudo docker compose build
sudo docker compose up -d

echo ""
echo "==> ✅ تم النشر بنجاح!"
echo ""
echo "افتح المتصفح على: $(grep REACT_APP_BACKEND_URL .env | cut -d= -f2)"
echo "بيانات الدخول الافتراضية: admin / admin123"
echo ""
echo "⚠️  مهم: غيّر كلمة مرور admin من قاعدة البيانات بعد أول دخول"
echo ""
echo "لمتابعة السجلات:  sudo docker compose logs -f"
echo "لإيقاف النظام:    sudo docker compose down"
