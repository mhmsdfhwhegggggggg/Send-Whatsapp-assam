import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { LayoutDashboard, Users, FolderKanban, FileText, Smartphone, Send, Settings, LogOut, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  { to: "/", icon: LayoutDashboard, label: "الرئيسية", end: true, id: "dashboard" },
  { to: "/students", icon: Users, label: "المستفيدون", id: "students" },
  { to: "/groups", icon: FolderKanban, label: "المجموعات", id: "groups" },
  { to: "/templates", icon: FileText, label: "قوالب الرسائل", id: "templates" },
  { to: "/accounts", icon: Smartphone, label: "حسابات واتساب", id: "accounts" },
  { to: "/campaigns", icon: Send, label: "الحملات", id: "campaigns" },
  { to: "/settings", icon: Settings, label: "الإعدادات", id: "settings" },
];

export default function Layout() {
  const nav = useNavigate();
  const user = JSON.parse(localStorage.getItem("user") || "{}");

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    nav("/login");
  };

  return (
    <div className="min-h-screen flex bg-[#F4F5F7]" data-testid="app-layout">
      {/* Sidebar on RIGHT for RTL */}
      <aside className="w-64 bg-white border-l border-slate-200 flex flex-col fixed right-0 top-0 bottom-0 z-30">
        <div className="p-5 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#1B7A3D] to-[#145D2E] flex items-center justify-center text-white">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <div className="font-heading font-bold text-slate-900 text-sm leading-tight">المؤسسة الوطنية</div>
              <div className="text-xs text-slate-500">نظام الإرسال</div>
            </div>
          </div>
        </div>

        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              data-testid={`sidebar-${item.id}-link`}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-[#E8F5EE] text-[#1B7A3D]"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                }`
              }
            >
              <item.icon className="w-5 h-5 shrink-0" />
              <span>{item.label}</span>
            </NavLink>
          ))}
        </nav>

        <div className="p-3 border-t border-slate-100">
          <div className="flex items-center gap-3 px-2 py-2 mb-2">
            <div className="w-9 h-9 rounded-full bg-[#FCE9EA] text-[#C41E24] font-bold flex items-center justify-center text-sm">
              {(user.username || "A").charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-slate-900 truncate">{user.username || "مدير"}</div>
              <div className="text-xs text-slate-500">{user.role || "admin"}</div>
            </div>
          </div>
          <Button variant="ghost" onClick={logout} data-testid="logout-button"
            className="w-full justify-start text-slate-600 hover:text-[#C41E24] hover:bg-[#FCE9EA] gap-2">
            <LogOut className="w-4 h-4" />
            تسجيل الخروج
          </Button>
        </div>
      </aside>

      <main className="flex-1 mr-64 p-6 lg:p-8">
        <Outlet />
      </main>
    </div>
  );
}
